#include "final_project.h"
/*this file contains the main*/

int main(int argc,char* argv[])
{
	char file_name[LINE_LENGTH];/*to be able to add the endings to the files.*/
	int i = 1;
	FILE* ptr;
	if (argc == 1)/*if argc is one then no files were added which is an error.*/
	{
		fprintf(stdin, "\nno files added");
		return 0;
	}
	for (i = 1;i < argc;i++)/*going over every file that was sent.*/
	{
		memset(file_name, 0, LINE_LENGTH);
		strcat(file_name, argv[i]);/*copying the file name into file_name to change it for every file.*/
		ptr = fopen(strcat(file_name,".as"), "r");  /* opening the input file with the as ending.*/
		if ((ptr == NULL))/*check to see that ptr file is open*/
		{
			printf("\nptr file can not open");
			return 1;
		}
		remove_file_endname(file_name);/*removing the as ending for the next file.*/
		create_mcro_file(ptr,file_name);/*this function creates the file after mcro cycle and then calls for firstCycle that calls for secendCycle.*/
	}
	return 0;
}


