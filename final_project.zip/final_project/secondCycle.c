#include "final_project.h"
/*this file contains the main functions for the second cycle*/



/*this function is the second cycle, it translate the code into binary words and then prints the correct output files.
param - inst_head - a pointer to the pointer of the head of the instruction list.
param - label_head - a pointer to the pointer of the head of the label list.
param - data_head - a pointer to the pointer of the head of the data list.
param - externs - an array of strings of the labels that are declared as extern.
param - entrys - an array of strings of the labels that are declared as entry.
param - extern_length - the length of labels in externs.
param - entry_length - the length of labels in entrys.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.
param - the name of the input file.*/
void secondCyrcle(instruct** inst_head, label** label_head, data** data_head, char* externs[LABEL_LENGTH], char* entrys[LABEL_LENGTH], short extern_length, short entry_length, char* flag, char* file_name)
{
	short inst_word_length = 0;
	short data_word_length = 0;
	state_list* state_head;
	FILE* object_file=NULL;
	FILE* entry_file=NULL;
	FILE* extern_file=NULL;
	remove_file_endname(file_name);
	if(entry_length)
		entry_file = fopen(strcat(file_name, ".ent"), "w+");/*opening the entry file with the ".ent" ending*/
	remove_file_endname(file_name);
	if(extern_length)
		extern_file = fopen(strcat(file_name, ".ext"), "w+");/*opening the extern file with the ".ext" ending*/
	state_head = NULL;
	add_instruct_to_list(&state_head, inst_head, label_head, data_head, externs, extern_length, flag, extern_file);/*this function goes over the instruct list and translate it to binary code in word form on the statement list.*/
	count_word_length(&inst_word_length, &state_head);/*counts the amount of words in the statement list.*/
	add_data_to_list(data_head, &state_head);/*this function goes over the data list and translate it to binary code in word form on the statement list.*/
	count_word_length(&data_word_length, &state_head);/*counts the amount of words in the statement list.*/
	data_word_length = data_word_length - inst_word_length;/*the amount of data words would be the amount after adding the data list minus the amount before.*/
	if (!(*flag))/*if there were no errors then print into the files.*/
	{
		remove_file_endname(file_name);
		object_file = fopen(strcat(file_name, ".ob"), "w+");/*opening the object file with the ".ob" ending.*/
		write_object_file(object_file, &state_head, data_word_length, inst_word_length);/*translates the binary code into base64 code for the file.*/
		if(entry_length)
			write_entry_file(entry_file, label_head, entrys, entry_length);/*writes the entry and extern files.*/
		fclose(object_file);/*closing the object file.*/
	}
	free_extern_entry(externs, extern_length);/*this function frees the extern array.*/
	free_extern_entry(entrys, entry_length);/*this function frees the entry array.*/
	free_state_list(&state_head);/*this function frees the function list.*/
	if(entry_length)
		fclose(entry_file);/*closing the entry file.*/
	if(extern_length)
		fclose(extern_file);/*closing the extern file.*/
}

/*this function goes over the data list and translate it to binary code in word form on the statement list.
param - state_head - a pointer to the pointer of the head of the statement list.
param - inst_head - a pointer to the pointer of the head of the instruction list.
param - label_head - a pointer to the pointer of the head of the label list.
param - data_head - a pointer to the pointer of the head of the data list.
param - externs - an array of strings of the labels that are declared as extern.
param - extern_length - the length of labels in externs.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.
param - extern_file - a pointer to the extern file.*/
void add_instruct_to_list(state_list** state_head, instruct** inst_head, label** label_head, data** data_head, char* externs[LABEL_LENGTH], short extern_length, char* flag, FILE* extern_file)
{
	int source_type, dest_type;
	state_list* state_tmp = (*state_head);
	instruct* inst_tmp = (*inst_head);
	if (*state_head)/*if head is not null then there is already a list and need to get to the last one.*/
	{
		while (state_tmp->next)
			state_tmp = state_tmp->next;
		state_tmp->next = (state_list*)malloc(sizeof(state_list));/*adding a new node in the list.*/
		state_tmp = state_tmp->next;
	}
	else
	{
		state_tmp = (state_list*)malloc(sizeof(state_list));/*if head is null then add the first node in the list*/
		(*state_head) = state_tmp;/*connect head to the start of the list.*/
	}
	state_tmp->next = NULL;
	while (inst_tmp)/*going over the struct list to add it to the state list.*/
	{
		source_type = 0;
		dest_type = 0;
		state_tmp->word = 0;
		(state_tmp->word) = (state_tmp->word) | (inst_tmp->commend << COMMAND);/*adding the commend number to the word from the 5th bit.*/
		if (((inst_tmp->commend >= 0) && (inst_tmp->commend < 4)) || (inst_tmp->commend == 6))/*those commends reqoire two parameters.*/
		{
			state_tmp->next = (state_list*)malloc(sizeof(state_list));/*adding another word for the parameter.*/
			state_tmp->next->next = NULL;
			if (is_register(inst_tmp->source, flag, inst_tmp->line,1) && is_register(inst_tmp->dest, flag, inst_tmp->line,1))/*if both of the peremeters are registers then need only one word with both registers.*/
			{
				get_two_registers(state_tmp->next, inst_tmp, flag);/*adds both registers to the same word.*/
				(state_tmp->word) = (state_tmp->word) | (REGISTER << SOURCE);/*the source perem would be 5 from the 9th bit.*/
				(state_tmp->word) = (state_tmp->word) | (REGISTER << DEST);/*the destination perem would be 5 from the 2th bit.*/
				state_tmp = state_tmp->next;/*updating state_tmp to the last node.*/
			}
			else
			{
				source_type = get_operand(inst_tmp->source, state_tmp->next, state_head, label_head, externs, extern_length, flag, inst_tmp->line, extern_file);/*this function adds the source operand to the next word and returns the oparend type.*/
				if (source_type == REGISTER)/*if it is a register then add it to the correct bits for a source.*/
					(state_tmp->word) = (state_tmp->word) | (REGISTER << REGISTER_SOURCE);
				source_operand_check(source_type, inst_tmp, flag);/*checks if the type of the source operand is correct to the command type.*/
				state_tmp->next->word = (state_tmp->next->word) | ((source_type) << SOURCE);/*adds the source operand type to the word from the 9th bit.*/
				state_tmp->next->next = (state_list*)malloc(sizeof(state_list));/*adding another node for the dest operand.*/
				state_tmp->next->next->next = NULL;
				dest_type = get_operand(inst_tmp->dest, state_tmp->next->next, state_head, label_head, externs, extern_length, flag, inst_tmp->line, extern_file);/*this function adds the dest operand to the next word and returns the oparend type.*/
				if (dest_type == REGISTER)/*if it is a register then add it to the correct bits for a dest.*/
					(state_tmp->next->next->word) = (state_tmp->next->next->word) | (dest_type << DEST);
				dest_operand_check(dest_type, inst_tmp, flag);/*checks if the type of the dest operand is correct to the command type.*/
				state_tmp->word = (state_tmp->word) | ((dest_type) << DEST);/*adds the dest operand type to the word from the 2th bit.*/
				state_tmp = state_tmp->next->next;/*updating state_tmp to the last node.*/
			}
		}
		else if (((inst_tmp->commend > 3) && (inst_tmp->commend < 6)) || ((inst_tmp->commend > 6) && (inst_tmp->commend < 14)))/*those commends reqoire one parameter.*/
		{
			state_tmp->next = (state_list*)malloc(sizeof(state_list));/*adding another word for the parameter.*/
			state_tmp->next->next = NULL;
			dest_type = get_operand(inst_tmp->dest, state_tmp->next, state_head, label_head, externs, extern_length, flag, inst_tmp->line, extern_file);/*this function adds the dest operand to the next word and returns the oparend type.*/
			if (dest_type == REGISTER)/*if it is a register then add it to the correct bits for a dest.*/
				(state_tmp->next->word) = (state_tmp->next->word) | (REGISTER << DEST);
			dest_operand_check(dest_type, inst_tmp, flag);/*checks if the type of the dest operand is correct to the command type.*/
			state_tmp->word = (state_tmp->word) | (dest_type << DEST);/*adds the dest operand type to the word from the 2th bit.*/
			state_tmp = state_tmp->next;/*updating state_tmp to the last node.*/
		}
		if (inst_tmp->next)/*if there are more instructions then add another state node.*/
		{
			state_tmp->next = (state_list*)malloc(sizeof(state_list));
			state_tmp = state_tmp->next;
			state_tmp->next = NULL;
		}
		inst_tmp = inst_tmp->next;
	}
}

/*this function adds the operand to the word and returns the type of the operand.
param - param - the parameter to add to the word.
param - state_tmp - the state node to add the param to the word of.
param - state_head - a pointer to the pointer of the head of the state list.
param - label_head - a pointer to the pointer of the head of the label list.
param - externs - an array of strings of the labels that are declared as extern.
param - extern_length - the length of labels in externs.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.
param - line_count - the line of the instruction.
param - extern_file - a pointer to the extern file.
return - returns 5 if it is a register, 1 if it's a number, 3 if it's a label.*/
int get_operand(char* param, state_list* state_tmp, state_list** state_head, label** label_head, char* externs[LABEL_LENGTH], short extern_length, char* flag, short line_count, FILE* extern_file)
{
	state_tmp->word = 0;
	if (is_register(param, flag, line_count,1))/*this function returns not 0 if it's a register.*/
	{
		return REGISTER;/*we can't fill the state_tmp word becouse we don't know if the operand is dest or source.*/
	}
	if (is_number(param))/*this function returns not 0 if it's a number.*/
	{
		(state_tmp->word) = (state_tmp->word) | (is_number(param) << 2);
		return NUMBER;
	}
	if (is_label(param, label_head))/*this function returns not 0 if it's a label.*/
	{
		(state_tmp->word) = (state_tmp->word) | (is_label(param, label_head) << 2);
		state_tmp->word = state_tmp->word + 2;
		return LABEL;
	}
	if (is_extern(param, externs, extern_length, extern_file, state_head))/*this function returns not 0 if it's a label that was declared extern.*/
	{
		state_tmp->word = 1;
		return LABEL;
	}
	printf("\nline %d - not a valid parameter", line_count);/*if it didn't pass any of the checks then it's not a valid parameter.*/
	*flag = 1;
	return 0;
}

/*this function adds two register numbers into the same number.
param - state_tmp - the state node to add the param to the word of.
param - inst_tmp - the instruct node where the registers are from.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.*/
void get_two_registers(state_list* state_tmp, instruct* inst_tmp, char* flag)
{
	state_tmp->word = 0;
	(state_tmp->word) = (state_tmp->word) | (is_register(inst_tmp->dest, flag, inst_tmp->line,1) << 2);/*adding the register number of the dest from the 2th bit.*/
	(state_tmp->word) = (state_tmp->word) | (is_register(inst_tmp->source, flag, inst_tmp->line,1) << REGISTER_SOURCE);/*adding the register number of the source from the 6th bit.*/
}

/*adding the data list to the words in the state list.
param - data_head - a pointer to the pointer of the head of the data list.
param - state_head - a pointer to the pointer of the head of the state list.*/
void add_data_to_list(data** data_head, state_list** state_head)
{
	state_list* state_tmp = (*state_head);
	data* data_tmp = (*data_head);
	if (*state_head)/*if head is not null then there is already a list and need to get to the last one.*/
	{
		while (state_tmp->next)
			state_tmp = state_tmp->next;
		state_tmp->next = (state_list*)malloc(sizeof(state_list));/*adding a new node in the list.*/
		state_tmp = state_tmp->next;
	}
	else
	{
		state_tmp = (state_list*)malloc(sizeof(state_list));/*if head is null then add the first node in the list*/
		(*state_head) = state_tmp;/*connect head to the start of the list.*/
	}
	state_tmp->next = NULL;
	while (data_tmp)/*going over the data list to add to the state list.*/
	{
		state_tmp->word = data_tmp->content;/*adding the content to the word.*/
		if (data_tmp->next)/*if there is more data then add another state word.*/
		{
			state_tmp->next = (state_list*)malloc(sizeof(state_list));
			state_tmp = state_tmp->next;
		}
		state_tmp->next = NULL;
		data_tmp = data_tmp->next;
	}
}


/*this function writes the object file with the .ob ending.
param - ptr - a pointer to the object file.
param - state_head - a pointer to the pointer of the head of the state list.
param - data_word_length - the length of words that contain data.
param - inst_word_length - the length of words that contain instructions.*/
void write_object_file(FILE* ptr, state_list** state_head, short data_word_length, short inst_word_length)
{
	char base64[] = { 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X'
	,'Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'
	,'0','1','2','3','4','5','6','7','8','9','+','/' };/*an arrey to use the base64 system.*/
	unsigned int num = 0;
	state_list* state_tmp = *state_head;
	fprintf(ptr, "%d %d\n", inst_word_length, data_word_length);/*print first the lengths of data and instruct.*/
	while (state_tmp)/*goes over the sate list.*/
	{
		num = SIX_ONE_BITS & ((state_tmp->word) >> 6);/*taking the first 6 bits by moving them right.*/
		fprintf(ptr, "%c", base64[num]);/*print the correct char using the base64 system.*/
		num = (state_tmp->word) & SIX_ONE_BITS;/*taking the last 6 bits with & six times bits of one.*/
		fprintf(ptr, "%c\n", base64[num]);/*print the correct char using the base64 system.*/
		state_tmp = state_tmp->next;
	}
}

/*prints all the labels that were defined as entry.
param - ptr - a pointer to the entry list.
param - label_head - a pointer to the pointer of the head of the label list.
param - entrys - an array of strings of the labels that are declared as entry.
param - entry_length - the length of labels in entrys.*/
void write_entry_file(FILE* ptr, label** label_head, char* entrys[LABEL_LENGTH], short entry_length)
{
	int i;
	for (i = 0;i < entry_length;i++)/*foes over the labels in the entry array.*/
	{
		label* label_tmp = *label_head;
		while (label_tmp)/*going over the label list to compare.*/
		{
			if (!(strcmp(entrys[i], label_tmp->name)))/*if it is the right label then print the name and the IC value of where it was defined.*/
			{
				fprintf(ptr, "%s\t%d\n", entrys[i], label_tmp->memory);
				break;
			}
			label_tmp = label_tmp->next;
		}
	}
}

/*this function counts the amount of words that curentry exist.
param - length - the length of the words to update.
param - state_head - a pointer to the pointer of the head of the state list.*/
void count_word_length(short* length, state_list** state_head)
{
	state_list* state_tmp = *state_head;
	while (state_tmp)/*counts the state list.*/
	{
		(*length)++;
		state_tmp = state_tmp->next;
	}
}

