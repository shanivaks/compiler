#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define INCREASE(X) (X)+5
#define LINE_LENGTH 81
#define LABEL_LENGTH 32
#define IC_START 100
#define SIX_ONE_BITS 0x3F
enum type{DATA,STRING,INSTRUCTION};
enum size{ONE_WORD=1,TWO_WORD,THREE_WORD};
enum operand_adress{NUMBER=1,LABEL=3,REGISTER=5};
enum operand_place{DEST=2,COMMAND=5,REGISTER_SOURCE=7,SOURCE=9};
typedef struct State_list {
	short word;
	struct State_list* next;
}state_list;

typedef  struct Mcro {
	char* name;
	char* content;
	struct Mcro* next;
}mcro;
/*type- 0=.data 1=.string 2=instruction*/
typedef struct Label {
	char name[LABEL_LENGTH];
	short type;
	short memory;
	struct Label* next;
} label;

typedef struct Data {
	short DC;
	short content;
	struct Data* next;
}data;

typedef struct Instruct {
	short line;
	short IC;
	char commend;
	char source[LABEL_LENGTH];
	char dest[LABEL_LENGTH];
	char size;
	struct Instruct* next;
}instruct;
void create_mcro_file(FILE* ptr,char* file_name);
FILE* create_mcro_list(mcro** head, FILE* ptr, FILE* aftermcro);
void get_mcro(mcro** head, FILE* ptr, char* name);
void free_mcro(mcro** head);
int empty_line_check(char* line);
void remove_white_spaces(char* str);
void first_cycle(instruct **inst_head,label** label_head, data** data_head, FILE* pre_compiler,char* file_name);
void get_label(label** label_head, data** data_head, instruct** inst_head, FILE* ptr, char* line, short line_count, char* flag, char* externs[LABEL_LENGTH], char* entrys[LABEL_LENGTH], short* extern_length, short* entry_length);
short get_data(data** data_head, char* str, short type, short line_count, char* problem_flag);
short get_data_char(char** str, short* flag, short line_count, char* problem_flag);
short get_data_number(char** str, short* flag, short line_count, char* problem_flag);
void free_label(label** label_head);
void free_data(data** data_head);
void free_instruct(instruct** inst_head);
short create_instruct_list(instruct** inst_head, char* line, short line_count, char* flag);
void add_instruct_node(instruct* inst_tmp, char* line, short* curIC, short line_count, char* flag);
void get_extern_entry(char* first_array[LABEL_LENGTH], short* first_array_length,char* second_array[LABEL_LENGTH], short* second_array_length, char* line,short line_count,char* flag);
void print_extern_entry(char *externs[LABEL_LENGTH],short extern_length);
char is_register(char* param, char* flag, short line_count,char print);
short instruction_list_length(instruct** inst_head);
void update_adress(label** label_head, data** data_head, short instruct_length);
void secondCyrcle( instruct** inst_head, label** label_head, data** data_head, char *externs[LABEL_LENGTH], char *entrys[LABEL_LENGTH], short extern_length,short entry_length,char* flag,char* file_name);
void add_instruct_to_list(state_list** state_head, instruct** inst_head, label** label_head, data** data_head, char *externs[LABEL_LENGTH], short extern_length, char* flag, FILE* extern_file);
int get_operand(char* perem, state_list* state_tmp, state_list** state_head, label** label_head, char *externs[LABEL_LENGTH], short extern_length, char* flag, short line_count, FILE* extern_file);
int is_number(char* perem);
int is_label(char* perem, label** label_head);
int is_extern(char* perem, char *externs[LABEL_LENGTH], short extern_length, FILE* ptr, state_list** state_head);
void get_two_registers(state_list* state_tmp, instruct* inst_tmp, char* flag);
void free_state_list(state_list** state_head);
void print_statement(state_list** state_head, FILE* ptr);
void add_data_to_list(data** data_head, state_list** state_head);
void source_operand_check(int operand_type, instruct* inst_tmp, char* flag);
void dest_operand_check(int operand_type, instruct* inst_tmp, char* flag);
void write_object_file(FILE* ptr, state_list** state_head, short data_word_length, short inst_word_length);
void write_entry_file(FILE* ptr, label** label_head, char *entrys[LABEL_LENGTH], short entry_length);
void count_word_length(short* length, state_list** state_head);
void remove_file_endname(char* file_name);
void free_extern_entry(char*externs[LABEL_LENGTH],short extern_length);
