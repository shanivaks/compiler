#include "final_project.h"
/*this file contians all the functions that are connected to labels (data/string/instruction).*/

/*this finction gets a line with a label definition and adds it to the label list (or data/instruction list if needed)
param - label_head - a pointer to the pointer of the head of the label list.
param - data_head - a pointer to the pointer of the head of the data list.
param - inst_head - a pointer to the pointer of the head of the instruction list.
param - ptr - the file after the mcro cycle.
param - str - the name of the label.
param - line - the definition of the label
param - line_count - the line number for errors.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.*/
void get_label(label** label_head, data** data_head, instruct** inst_head, FILE* ptr, char* line, short line_count, char* flag, char* externs[LABEL_LENGTH], char* entrys[LABEL_LENGTH], short* extern_length, short* entry_length)
{
	char str[LABEL_LENGTH] = "";
	char type[10];
	char *content;
	char* instructstart;
	label* tmp = (*label_head);
	sscanf(line, "%s %s", str, type);/*dividing the line into the name,type and content.*/
	content = strchr(line, ' ') + 1;
	content = strchr(content, ' ') + 1;
	if (!strcmp(type, ".extern"))
	{
		get_extern_entry(externs, extern_length, entrys, entry_length, line, line_count, flag);
		return;
	}
	if (!strcmp(type, ".entry"))
	{
		get_extern_entry(entrys, entry_length, externs, extern_length, line, line_count, flag);
		return;
	}
	*(strchr(str, ':')) = '\0';
	while (tmp)/*going over the list to check if the label was already defined.*/
	{
		if (!strcmp(str, tmp->name))
		{
			printf("\nline %d - this label was already defined", line_count);
			*flag = 1;
			return;
		}
		tmp = tmp->next;
	}
	tmp = (*label_head);/*returning tmp to the start of the label list.*/
	if (*label_head)/*if head is not null then there is already a list and need to get to the last one.*/
	{
		while (tmp->next)
			tmp = tmp->next;
		tmp->next = (label*)malloc(sizeof(label));/*adding a new node in the list.*/
		tmp = tmp->next;
	}
	else
	{
		tmp = (label*)malloc(sizeof(label));/*if head is null then add the first node in the list*/
		*label_head = tmp;/*connect head to the start of the list.*/
	}
	tmp->next = NULL;
	memset(tmp->name, 0, sizeof(tmp->name));
	strcat(tmp->name, str);
	if (!strcmp(type, ".data"))/*if type is data then the type of the node will be 0.*/
		tmp->type = DATA;
	else if (!strcmp(type, ".string"))/*if type is string then the type of the node will be 1.*/
		tmp->type = STRING;
	else/*if the type is not spesified then it is an instruction and the type of the node will be 2*/
	{
		instructstart = (strchr(line, ' ') + 1);/*starting the instruction after the label definition.*/
		tmp->type = INSTRUCTION;
		tmp->memory = create_instruct_list(inst_head, instructstart, line_count, flag);/*the place in the memory of the label would be the start of the instruction node. the function adds the instruction to the inxtruction list. */
	}
	if ((tmp->type == DATA) || (tmp->type == STRING))/*of the label is data then add it to the data list.*/
		tmp->memory = get_data(data_head, content, tmp->type, line_count, flag);/*get data adds the label to the data list and returns to place in memory of the first number/char.*/
}


/*this function adds the label definition to the data list.
param - data_head - a pointer to the pointer of the head of the data list.
param - str - the content of the label.
param - type - the type of the label (string/data).
param - line_count - the line number for errors.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.
return - the DC value of the first number in the string.*/
short get_data(data** data_head, char* str, short type, short line_count, char* problem_flag)
{
	short flag = 1;
	short curDC, returnDC;
	data* tmp = (*data_head);
	if (*data_head)/*going over the list to check if the label was already defined.*/
	{
		while (tmp->next)
			tmp = tmp->next;
		curDC = tmp->DC;/*the curent DC would be the DC of the last node*/
		tmp->next = (data*)malloc(sizeof(data));/*adding a new node in the list.*/
		tmp = tmp->next;
		curDC++;
	}
	else
	{
		tmp = (data*)malloc(sizeof(data));/*if head is null then add the first node in the list*/
		*data_head = tmp;/*connect head to the start of the list.*/
		curDC = 0;/*if the list is empty then the DC is 0.*/
	}
	tmp->next = NULL;
	returnDC = curDC;/*saving the curent DC to return later.*/
	if (type == DATA)/*if type is data then need to take numbers*/
	{
		while (flag)/*while there are more numbers in string.*/
		{
			tmp->content = get_data_number(&str, &flag, line_count, problem_flag);/*this function gets one number at a time from the string and return the value. if there are no more numbers then flag=0.*/
			tmp->DC = curDC;/*adding the DC value to the number.*/
			curDC++;/*updating the DC value.*/
			if (flag)/*if there are more numbers then add a new node to the data list.*/
			{
				tmp->next = (data*)malloc(sizeof(data));
				tmp = tmp->next;
			}
			tmp->next = NULL;

		}

	}
	if (type == STRING)/*if type is string then need to take chars*/
	{
		if ((*str) != '"')/*the first char in the string needs to be '"'.*/
		{
			printf("\nline %d - not a string", line_count);
			*problem_flag = 1;
			return 0;
		}
		str++;
		while (flag)/*while there are more chars in string.*/
		{
			tmp->content = get_data_char(&str, &flag, line_count, problem_flag);/*this function gets one char at a time from the string and return the value. if there are no more chars then flag=0.*/
			tmp->DC = curDC;/*adding the DC value to the number.*/
			curDC++;/*updating the DC value.*/
			if (flag)/*if there are more chars then add a new node to the data list.*/
			{
				tmp->next = (data*)malloc(sizeof(data));
				tmp = tmp->next;
			}
			tmp->next = NULL;
		}

	}
	return returnDC;/*return the DC value if the first data node in the function call.*/
}

/*this function returns the ascii number of the first char in the string. and then the function moves the pointer one char after.
param - str - a pointer to the string.
param - flag - 1 if there are more chars in the string and 0 if it is the end of the string.
param - line_count - the number of the line in the file, for errors.
param - problem_flag - a pointer to a flag, if there is an error then turn flag to 1.*/
short get_data_char(char** str, short* flag, short line_count, char* problem_flag)
{
	short num;
	if (**str == '"')/*if the char is '"' then it is the end of the string and need to add a 0 at the end.*/
	{
		*flag = 0;
		return 0;
	}
	if (**str == 0)/*if the end '\0' is reached without a '"' then there is an error*/
	{
		printf("\nline %d - no end to string", line_count);
		*problem_flag = 1;
		*flag = 0;
		return 0;
	}
	num = (short)(**str);
	(*str)++;/*moving the str pointer one char over.*/
	return num;/*return the ascii value of the char.*/
}

/*this function returns the value of the first number in the string. and then the function moves the pointer to the next number.
param - str - a pointer to the string.
param - flag - 1 if there are more chars in the string and 0 if it is the end of the string.
param - line_count - the number of the line in the file, for errors.
param - problem_flag - a pointer to a flag, if there is an error then turn flag to 1.*/
short get_data_number(char** str, short* flag, short line_count, char* problem_flag)
{
	short num;
	if (((**str) < 48 || (**str) > 57) && (**str != '-') && (**str != '+'))/*if the char is not a number, nor is it +/- then there is an error.*/
	{
		if (**str == '\0')/*if it is the end of the string that means that there is an extra comma at the end*/
			printf("\nline %d - problem with .data- extra comma at the end", line_count);
		else if (**str == ',')/*if there is a comma then that means that there is an extra comma on the middle.*/
			printf("\nline %d - problem with .data- extra comma", line_count);
		else/*anything alse is just not a number.*/
			printf("\nline %d - problem with .data- not a number", line_count);
		*problem_flag = 1;
		*flag=0;
		return 0;
	}
	num = (short)(strtol(*str, str, 10));/*geting the number from the string using the strtol function.*/
	if ((**str != '\0') && (**str != ' ') && (**str != '\t') && (**str != ','))
	{
		printf("\nline %d - problem with .data- not a number", line_count);
		*problem_flag = 1;
		*flag=0;
		return 0;
	}
	while ((**str == ' ') || (**str == '\t'))
		(*str)++;
	if (**str == '\0')/*if it's the end of the string then flag is zero.*/
	{
		*flag = 0;
		return num;
	}
	if (**str == ',')/*if there is a comma that means that there is another number in the string.*/
	{
		(*str)++;
		return num;
	}
	if (((**str > 47) && (**str <= 57))|| (**str == '-') || (**str == '+'))
	{
		printf("\nline %d - problem with .data- no comma between two numbers.", line_count);
		*problem_flag = 1;
		*flag=0;
		return 0;
	}
	printf("\nline %d - problem with .data- not a number", line_count);/*if there is no comma then that is an error.*/
	*problem_flag = 1;
	*flag=0;
	return 0;
}

/*this function apdates the IC of the data acording to the length of the instructions.
param - label_head - a pointer to the pointer of the head of the label list.
param - data_head - a pointer to the pointer of the head of the data list.
param - instruct_length - the length (in words) of the instruct list.*/
void update_adress(label** label_head, data** data_head, short instruct_length)
{
	label* label_tmp = (*label_head);
	data* data_tmp = (*data_head);
	while (data_tmp)/*updating the IC in the data list.*/
	{
		data_tmp->DC = data_tmp->DC + instruct_length + IC_START;
		data_tmp = data_tmp->next;
	}
	while (label_tmp)
	{
		if ((label_tmp->type == DATA) || (label_tmp->type == STRING))/*updating the labels of data and string acourding to the length of the istruct list.*/
		{
			label_tmp->memory = label_tmp->memory + instruct_length + IC_START;
		}
		else
			label_tmp->memory = label_tmp->memory + IC_START;/*ading 100 becouse that is the start of the IC.*/
		label_tmp = label_tmp->next;
	}
}
