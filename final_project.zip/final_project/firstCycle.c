#include "final_project.h" 
/*this function contains the main functions for the first cycle.*/




/*this function goes over the intire file and adds the instructions/data/labels to the right list to be able to use in the next cycle. then the function calls for the second cycle.
param - inst_head - a pointer to the pointer of the head of the instruction list.
param - label_head - a pointer to the pointer of the head of the label list.
param - data_head - a pointer to the pointer of the head of the data list.
param - pre_compiler - the file after the mcro cycle.
param - file_name - the name of the input file(with a diffrent ending).*/ 
void first_cycle(instruct** inst_head, label** label_head, data** data_head, FILE* pre_compiler, char* file_name)
{
	short extern_length = 0, entry_length = 0, instruct_length = 0, line_count = 0;
	char flag = 0;
	char line[LINE_LENGTH] = { 0 };
	char str[LABEL_LENGTH];
	char* externs[LABEL_LENGTH];
	char* entrys[LABEL_LENGTH];
	while ((fgets(line, LINE_LENGTH, pre_compiler) != NULL)
		&& !ferror(pre_compiler) && !feof(pre_compiler))/*geting a line from the file and checking for the end of the file.*/
	{
		line_count++;/*counting the lines for errors.*/
		*(strchr(line, '\n')) = '\0';/*removing the '\n' from the line.*/
		sscanf(line, "%s", str);/*geting the first word from the line.*/
		if (strchr(str, ':') == (strchr(str, '\0') - 1))/*if there is a ':' at the end of the first word then it is a label*/
		{
			get_label(label_head, data_head, inst_head, pre_compiler, line, line_count, &flag,externs,entrys,&extern_length,&entry_length);/*this function gets the label and adds it to the label list or data list or istruction list if needed.*/
			memset(line, 0, sizeof(line));
			continue;
		}
		if (!strcmp(str, ".extern"))/*if the first word is ".extern" then it is an extern definition.*/
		{
			get_extern_entry(externs, &extern_length,entrys, &entry_length, line,line_count,&flag);/*this function adds the label to the extern/entry array.*/
			memset(line, 0, sizeof(line));
			continue;
		}
		if (!strcmp(str, ".entry"))/*if the first word is ".entry" then it is an entry definition.*/
		{
			get_extern_entry(entrys,&entry_length,externs, &extern_length,line,line_count,&flag);
			memset(line, 0, sizeof(line));
			continue;
		}
		create_instruct_list(inst_head, line, line_count, &flag);/*if the line is a reguler instruction line then add to instruction list.*/
		memset(line, 0, sizeof(line));
	}
	instruct_length = instruction_list_length(inst_head);/*geting the amount of words in the instruction list.*/
	update_adress(label_head, data_head, instruct_length);/*updating the adresses of the label and data lists acording to the instructions.*/
	
	secondCyrcle(inst_head, label_head, data_head, externs, entrys, extern_length, entry_length, &flag, file_name);/*the call to the second cycle that will write the output files.*/
	free_label(label_head);/*need to erase before sending.*/
	free_data(data_head);/*need to erase before sending.*/
	free_instruct(inst_head);/*need to erase before sending.*/
}




/*this function adds another node to the instruct lsit.
param - inst_head - a pointer to the pointer of the head of the instruct list.
param - line - the instruction line to put in the instruct node.
param - line_count - the number of the line in the file, for errors.
param - flag - a pointer to a flag, if there is an error then turn flag to 1
return - the IC value of the beginning of the instruction.*/
short create_instruct_list(instruct** inst_head, char* line, short line_count, char* flag)
{
	short curIC, returnIC;
	instruct* tmp = *inst_head;
	if (*inst_head)/*going over the list to check if the label was already defined.*/
	{
		while (tmp->next)
			tmp = tmp->next;
		curIC = tmp->IC + tmp->size;/*the curent IC would be the IC of the last node + the size if the instruct (in words).*/
		tmp->next = (instruct*)malloc(sizeof(instruct));/*adding a new node in the list.*/
		tmp = tmp->next;
	}
	else
	{
		tmp = (instruct*)malloc(sizeof(instruct));/*if head is null then add the first node in the list*/
		*inst_head = tmp;/*connect head to the start of the list.*/
		curIC = 0;/*if the list is empty then the IC is 0.*/
	}
	tmp->next = NULL;
	returnIC = curIC;/*saving the curent IC value to return later.*/
	add_instruct_node(tmp, line, &curIC, line_count, flag);/*this function adds thr right parameters to the instruct node.*/
	tmp->size = (char)(curIC - returnIC);/*the size of the instruction (in words) is the new IC minus the IC from the biginning.*/
	tmp->line = line_count;/*saving the line count for posible errors in the next cycle.*/
	return returnIC;/*return the IC value of the start of the instruction.*/
}

/*this function adds thr right parameters to the instruct node.
param - inst_tmp - a pointer to the node we want to add the parameters to.
param - line - the string of the instruct.
param - the IC of the bigining of the instruction.
param - line_count - the line number of the instruct in case of errors.
param - flag -  a pointer to a flag, if there is an error then turn flag to 1.*/
void add_instruct_node(instruct* inst_tmp, char* line, short* curIC, short line_count, char* flag)
{
	const char* commends[16] = { "mov","cmp","add","sub","not","clr","lea","inc","dec","jmp","bne","red","prn","jsr","rts","stop" };/*an array of the correct commend names in the order of the opcode.*/
	char str[LABEL_LENGTH];
	char* param = "";
	char* dest;
	int i;
	sscanf(line, "%s", str);/*coping the first word to check for the commend name.*/
	if (strchr(line, ' '))
		param = strchr(line, ' ') + 1;/*removing the commend name from the parameters.*/
	remove_white_spaces(param);/*removing the white spaces from the parameters to be able to go over them.*/
	for (i = 0;i < 16;i++)/*going over the commend names to see what the instruction is.*/
	{
		if (!strcmp(str, commends[i]))
		{
			inst_tmp->commend = i;
			break;
		}
	}
	if (i == 16)/*if i=16 then that is not a correct command name.*/
	{
		printf("\nline %d - not a correct command name", line_count);
		*flag = 1;
		return;
	}
	memset(inst_tmp->source, 0, LABEL_LENGTH);
	memset(inst_tmp->dest, 0, LABEL_LENGTH);
	inst_tmp->IC = *curIC;/*adding the IC value to the node.*/
	if (((inst_tmp->commend >= 0) && (inst_tmp->commend < 4)) || (inst_tmp->commend == 6))/*those commends reqoire two parameters.*/
	{
		if (!strchr(param, ','))/*if there is no , then there are not anough parameters for those commends.*/
		{
			printf("\nline %d - not enough parameters", line_count);
			*flag = 1;
			return;
		}
		dest = strchr(line, ',') + 1;/*the destination parameter os the secend one.*/
		*strchr(line, ',') = '\0';/*removing the dest parameter from line.*/
		strcat(inst_tmp->source, param);/*param is a pointer to line, and only the source parameter is left.*/
		strcat(inst_tmp->dest, dest);/*ading the dest paraiter to the node. */
		if (is_register(param, flag, line_count,0) && is_register(dest, flag, line_count,0))/*if they are both parameters then the size of words would only be 2.*/
			inst_tmp->size = TWO_WORD;
		else
			inst_tmp->size = THREE_WORD;/*the amount of words for the instruction would be 3. */
	}
	else if (((inst_tmp->commend > 3) && (inst_tmp->commend < 6)) || ((inst_tmp->commend > 6) && (inst_tmp->commend < 14)))/*those commends reqoire one parameter.*/
	{
		if (strchr(param, ','))/*if there is a comma then there are too many parameters.*/
		{
			printf("\nline %d - too many parameters", line_count);
			*flag = 1;
			return;
		}
		strcat(inst_tmp->dest, param);/*adding the parameter to the dest param in the node.*/
		inst_tmp->size = TWO_WORD;/*the amount of words for the instruction would be 2. */
	}
	else/*the rest of the commends do not get any parameters.*/
	{
		if (strcmp(param, ""))/*if there is somthing after the commend name then there is an error.*/
		{
			printf("\nline %d - too many parameters", line_count);
			*flag = 1;
			return;
		}
		inst_tmp->size = ONE_WORD;/*the amount of words for the instruction would be 1. */
	}
	*curIC = (*curIC) + inst_tmp->size;/*updating the IC to the amount after the size.*/
}

/*counting the length of the words in the instruct list.
param - inst_head - a pointer to the pointer of the head of the instruction list.*/
short instruction_list_length(instruct** inst_head)
{
	short instruct_length = 0;
	instruct* tmp = (*inst_head);
	while (tmp)/*goes over the intire list*/
	{
		instruct_length = instruct_length + (short)tmp->size;/*ading the size of each instruct node.*/
		tmp = tmp->next;
	}
	return instruct_length;/*returning the length.*/
}

/*this function adds a label to the externs and entrys list.
param - first_array - the array to add a label to
param - first_array_length - the length of the array to add another label to.
param - second_array - the array to check that the label was not already defined in.
param - the length of the second array to ckeck with.
param - line - the line which the declaration is from.
param - line_count - the number of the line.
param - a flag for errors. turn into 1 if there is an error.*/
void get_extern_entry(char* first_array[LABEL_LENGTH], short* first_array_length,char* second_array[LABEL_LENGTH], short* second_array_length, char* line,short line_count,char* flag)
{
	int i;
	char str[LABEL_LENGTH];
	char label_name[LABEL_LENGTH]="";
	sscanf(line, "%s %s", str,label_name);/*ading the label to the array.*/
	for(i=0;i<(*first_array_length);i++)
	{
		if(!(strcmp(first_array[i],label_name)))
		{
			printf("\nline %d %d - a label has been defined twice, as entry or and as extern.", line_count, i);
			*flag=1;
			return;
		}
	}
	for(i=0;i<(*second_array_length);i++)
	{
		if(!(strcmp(second_array[i],label_name)))
		{
			printf("\nline %d - a label has been defined twice, as entry or and as extern.", line_count);
			*flag=1;
			return;
		}
	}
	first_array[*first_array_length] = (char*)malloc(sizeof(char) * LABEL_LENGTH);/*allocate memory space for the label*/
	memset(first_array[*first_array_length], 0, sizeof(char) * LABEL_LENGTH);
	strcat(first_array[*first_array_length], label_name);
	(*first_array_length)++;/*updating the length.*/
}

