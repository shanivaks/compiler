#include "final_project.h"
/*this file contains the functions for the pre_compiler stage.*/




/*this function creates the file after mcro cycle and then calls for firstCycle that calls for secendCycle. then the function frees all the lists that are made.
param- ptr - the input file
param file_name - the name of the input file without the ending.*/
void create_mcro_file(FILE* ptr,char* file_name)
{
	FILE *aftermcro;
	mcro* mcro_head = NULL;
	label* label_head = NULL;
	data* data_head = NULL;
	instruct* inst_head = NULL;
	aftermcro = fopen(strcat(file_name, ".am"), "w+");/*opening the .am file.*/
	if ((aftermcro == NULL))/*check to see that aftermcro file is open*/
		{
			printf("\naftermcro file can not open");
			return;
		}
	
	aftermcro = create_mcro_list(&mcro_head, ptr, aftermcro);/*foing over the intire input file to check for mcro and create a list. then the function writes the new file without the mcro/comments/empty lines*/
	fclose(ptr);/*closing the input file becouse now we have the file without mcro.*/
	fseek(aftermcro, 0, SEEK_SET);/*set the file to the start so we can go over it again in firstCycle.*/
	first_cycle(&inst_head, &label_head, &data_head, aftermcro, file_name);/*firstaCycle creates the label/data/instruction lists to be ready for secendCycle. then the function calls for secendCycle.*/
	fclose(aftermcro);
	free_mcro(&mcro_head);/*this function frees the mcro list.*/
}

/*this function goes over the input file and creates a list of mcro and copies the input file to the new file with chenges. if reads a mcro name then replaces it with the correct instructions. also if incounters a comment line or empty line then it will nit copy it to the new file
a mcro is defined with the "mcro" label and ends with "endmcro".
param - head - a pointer to the pointer of the head of the mcro list.
param - ptr - a pointer to the input file.
param - aftermcro - a pointer to the new file without mcro.*/
FILE* create_mcro_list(mcro** head, FILE* ptr, FILE* aftermcro)
{
	char flag = 1;
	mcro* tmp = NULL;
	char line[LINE_LENGTH];
	char str[10];
	char name[10];
	rewind(ptr);
	while (!feof(ptr))/*until the end of the input file.*/
	{
		flag = 1;
		fgets(line, LINE_LENGTH, ptr);/*goes over the file one line at a time.*/
		if (!sscanf(line, "%s", str))/*if can not scan the first word of the line then break.*/
			break;
		if (line[0] == ';')/*if the first char in the line is ';' then it is a comment line and not copy it to the new file.*/
			continue;
		if (empty_line_check(line))/*this function checks if the line is empty. returns 1 if empty and 0 if not. if empty then not copy it to the new file.*/
			continue;
		if (!strcmp(str, "mcro"))/*if the first word in the line is "mcro" then it is the start of a mcro defenition.*/
		{
			sscanf(line, "%s %s", str, name);/*name is to copy the name of the mcro*/
			get_mcro(head, ptr, name);/*this function adds the mcro to the mcro list.*/
			continue;
		}
		tmp = (*head);/*tmp is at the start of the updated mcro list.*/
		while (tmp)/*goes over the mcro list to check if a line is a mcro name.*/
		{
			if (!strcmp(str, tmp->name))/*checks if the first word in the line is a mcro name*/
			{
				fprintf(aftermcro, "%s", tmp->content);/*if it is then print the content of the mcro insted of the name.*/
				flag = 0;
			}
			tmp = tmp->next;
		}
		if (flag)/*if the word is not a mcro name or mcro definition then print the regular line. */
			fprintf(aftermcro, "%s", line);
	}
	return aftermcro;/*return the updated file.*/
}

/*gets a mcro defenition and adds it to the mcro list.
param - head - a pointer to the pointer of the head of the mcro list.
param - ptr - a pointer to the input file.
param - name - the name of the mcro that is being difined.*/
void get_mcro(mcro** head, FILE* ptr, char* name)
{
	int count = 0;
	char line[LINE_LENGTH];
	mcro* tmp = (*head);
	char* q;
	if (*head)/*if head is not null then there is already a list and need to get to the last one.*/
	{
		while (tmp->next)
			tmp = tmp->next;
		tmp->next = (mcro*)malloc(sizeof(mcro));/*adding a new node in the list.*/
		tmp = tmp->next;
	}
	else
	{
		tmp = (mcro*)malloc(sizeof(mcro));/*if head is null then add the first node in the list*/
		(*head) = tmp;/*connect head to the start of the list.*/
	}
	tmp->next = NULL;
	tmp->name = (char*)(malloc(sizeof(char) * 10));/*allocate memory space for the mcro name.*/
	memset(tmp->name, 0, sizeof(char) * 10);
	strcat(tmp->name, name);/*copying the name into the new mcro node.*/
	tmp->content = (char*)(malloc(sizeof(char) * LINE_LENGTH *2));/*allocate memory space for the content of the mcro*/
	memset(tmp->content, 0, sizeof(char) * LINE_LENGTH *2);
	while (!feof(ptr))
	{
		if (count > 2)
		{
			q = (char*)realloc(tmp->content, LINE_LENGTH * sizeof(char));/*if the mcro definition is too big then use realloc to allocate more space.*/
			if (q == NULL)/*if the realloc finction failed then print problem.*/
			{
				printf("\nproblem with memory in mcro-content");
				return;
			}
			tmp->content = q;
		}
		fgets(line,LINE_LENGTH, ptr);
		if (!strcmp(line, "endmcro\n"))
			break;
		strcat(tmp->content, line);/*adding each line in the definition to the content in node until line is "endmcro"*/
		count++;
	}
}

/*check if the line is empty (if it only has white spaces or tab or '\n' then it is still an empty line.
param - line - the line we want to check
return - 1 if it is empty. 0 if it is not empty.*/
int empty_line_check(char* line)
{
	char str[LINE_LENGTH] = "";/*new string in order to not change the original.*/
	strcat(str, line);/*copyies the line into the new string*/
	remove_white_spaces(str);/*this function removes evry white space or tab.*/
	if ((!strcmp(str, "")) || (!strcmp(str, "\n")))/*if the line is empty of '\n' then return 1*/
		return 1;
	return 0;/*if not empty then return 0.*/
}

/*removes the ending of a file name.
param - file_name - the name of the file we want to remove the ending from. */
void remove_file_endname(char* file_name)
{
	strtok(file_name, ".");
}
