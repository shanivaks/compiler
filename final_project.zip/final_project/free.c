#include "final_project.h" 

/*this file contains the functions that free lists/arrays.*/

/*this function frees the content and name arguments of mcro and then frees the mcro node itself. it does so for the intire mcro list.
param - head - a pointer to the pointer of the head of the mcro list.*/
void free_mcro(mcro** head)
{
	mcro* tmp = (*head);
	mcro* pNext = NULL;
	while (tmp != NULL)/*goes over the intire list*/
	{
		pNext = tmp->next;
		free(tmp->content);
		free(tmp->name);
		free(tmp);
		tmp = pNext;
	}
	*head = NULL;/*to make sure that head is null.*/
}

/*this function frees the label list.
param - label_head - a pointer to the pointer of the head of the label list.*/
void free_label(label** label_head)
{
	label* tmp = (*label_head);
	label* pNext = NULL;
	while (tmp != NULL)/*goes over the intire list.*/
	{
		pNext = tmp->next;
		free(tmp);
		tmp = pNext;
	}
	*label_head = NULL;
}

/*this function frees the data list.
param - data_head - a pointer to the pointer of the head of the data list.*/
void free_data(data** data_head)
{
	data* tmp = (*data_head);
	data* pNext = NULL;
	while (tmp != NULL)/*goes over the intire list.*/
	{
		pNext = tmp->next;
		free(tmp);
		tmp = pNext;
	}
	*data_head = NULL;
}

/*this function frees the instruct list.
param - inst_head - a pointer to the pointer of the head of the instruct list.*/
void free_instruct(instruct** inst_head)
{
	instruct* tmp = (*inst_head);
	instruct* pNext = NULL;
	while (tmp != NULL)/*goes over the intire list.*/
	{
		pNext = tmp->next;
		free(tmp);
		tmp = pNext;
	}
	*inst_head = NULL;
}

/*this function frees the state list.
param - state_head - a pointer to the pointer of the head of the state list.*/
void free_state_list(state_list** state_head)
{
	state_list* tmp = (*state_head);
	state_list* pNext = NULL;
	while (tmp != NULL)/*goes over the state list.*/
	{
		pNext = tmp->next;
		free(tmp);
		tmp = pNext;
	}
	*state_head = NULL;/*make sure that the head is null.*/
}

/*this function frees the extern/entry arrays.
param - array - the array of char pointers to free.
param - array_length - the length of hte array.*/
void free_extern_entry(char* array[LABEL_LENGTH], short array_length)
{
	int i;
	for (i = 0;i < array_length;i++)
	{
		free(array[i]);
	}
}
