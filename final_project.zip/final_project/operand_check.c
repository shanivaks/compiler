#include "final_project.h"
/*this file contains all the functions that check and/or change the operands/parameters.*/

/*this function removes the white spaces or tabs from the string
param - str - an arrey of chars, the string we want to change.*/
void remove_white_spaces(char* str)
{
	int i, non_space_count = 0;
	if (!strcmp(str, ""))/*if the line is empty there is no need to remove from it.*/
		return;
	for (i = 0; str[i] != '\0'; i++)/*goes over the string until '\0'*/
	{
		if ((str[i] != ' ') && (str[i] != '\t'))/*if a white space or tab then remove it from the string.*/
		{
			str[non_space_count] = str[i];
			non_space_count++;/*counts how meny chars there is without space.*/
		}
	}
	str[non_space_count] = '\0';/*adding '\0' to the end.*/
}

/*this function checks of the parameter is a register of not.
param - param - the parameter to check.
param - flag - a pointer to a flag, if there is an error then turn flag to 1.
param - line_count - the line number of the instruct in case of errors.
param - print - 0 if we want to print an error and 1 of we don't (we don't want to print the same error more then once).
return - the number of the register if it is a register and 1 if it's not.*/
char is_register(char* param, char* flag, short line_count,char print)
{
	char* str;
	char num;
	remove_white_spaces(param);/*in case there are any white spaces - remove them.*/
	if (!((*param == '@') && (*(param + 1) == 'r')))/*of the begining of the parameter is not "@r" then it's not a register.*/
		return 0;
	num = (char)(strtol((param + 2), &str, 10));/*taking the register number using the strtol function.*/
	if (num >= 0 && num < 8)/*the number needs to be between 0-7.*/
	{
		return num;
	}
	if (!print)/*if the function was already called to that register then there is no need to print the error again.*/
	{
		*flag = 1;
		printf("\nline %d - no such register exists", line_count);
	}
	return 0;
}

/*this function checks of the parameter is a number.
param - param - the parameter to check.
return - 0 if it's not a number and the value of the number of it is.*/
int is_number(char* param)
{
	char* str;
	int num;
	num= (int)strtol(param, &str, 10);/*if there is no number then num is 0 anyways.*/
	if(*str!='\0')
		return 0;
	return num;/*returns the value of the nuber using the strtol function (returns 0 if it's not a number.)*/
}

/*this function checks of the parameter is a label.
param - param - the parameter to check.
param - label_head - a pointer to the pointer of the head of the label list.
return - if it's not a label then return 0, return the label definition IC value.*/
int is_label(char* param, label** label_head)
{
	label* label_tmp = (*label_head);
	while (label_tmp)/*goes over the label list.*/
	{
		if (!(strcmp(label_tmp->name, param)))/*checks of the param is a label name.*/
			return label_tmp->memory;
		label_tmp = label_tmp->next;
	}
	return 0;
}

/*this function checks if the parameter is a label that was defined as extern.
param - param - the parameter to check.
param - externs - an array of strings of the labels that are declared as extern.
param - extern_length - the length of labels in externs.
param - ptr - a pointer to the extern file.
param - state_head - a pointer to the pointer of the head of the statement list.*/
int is_extern(char* param, char* externs[LABEL_LENGTH], short extern_length, FILE* ptr, state_list** state_head)
{
	int i;
	short length = 0;
	if(!ptr)
		return 0;
	count_word_length(&length, state_head);/*chechs the length of the amount of words so far.*/
	for (i = 0;i < extern_length;i++)/*goes over the externs array.*/
	{
		if (!(strcmp(param, externs[i])))/*if the param is the label name then print the label and the IC value of the word it was in.*/
		{
			fprintf(ptr, "\n%s\t%d", externs[i], length + IC_START-1);/*need to remove one becouse of the word for the param.*/
			return 1;
		}
	}
	return 0;
}

/*checks if the commend name eccepts the dest operand type.
param - operand_type - the number of the type of the dest operand type.
param - inst_tmp - the instruction that the operand is from.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.*/
void dest_operand_check(int operand_type, instruct* inst_tmp, char* flag)
{
	if ((operand_type == NUMBER) && ((inst_tmp->commend != 1) && (inst_tmp->commend != 12)))/*the operand type can't be 1 if the commend is not 1 or 12.*/
	{
		*flag = 1;
		printf("\nline %d - this commend can not accept a number as a destination", inst_tmp->line);
	}
}

/*checks if the commend name eccepts the souce operand type.
param - operand_type - the number of the type of the source operand type.
param - inst_tmp - the instruction that the operand is from.
param - flag -a pointer to a char, if an error acoures then sat flag to 1.*/
void source_operand_check(int operand_type, instruct* inst_tmp, char* flag)
{
	if ((operand_type == NUMBER || operand_type == REGISTER) && (inst_tmp->commend == 6))/*the operand type can't be 1 or 5 if the commend is 6.*/
	{
		*flag = 1;
		printf("\nline %d - this commend can not accept a number or a label as a source", inst_tmp->line);
	}
}
